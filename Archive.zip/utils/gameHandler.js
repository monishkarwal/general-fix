let lobby = [];

function generateRandomHash(length) {
  const haystack =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let output = "";
  for (let i = 0; i < length; i++) {
    output =
      output + haystack.charAt(Math.floor(Math.random() * haystack.length));
  }
  return output;
}

function createNewLobby(socket) {
  let gameData = {
    id: generateRandomHash(6),
    players: [],
    count: 0,
    isFull: false,
    board: [],
  };
  gameData.players.push({ player1: socket.id, color: "Yellow" });
  gameData.count = 1;
  socket.emit("room", { ...gameData });
  lobby.push(gameData);
  console.log("Lobby Initiated..");
  console.log("===================== LOBBY ============================");
  console.log(lobby);
  console.log("=================================================");
}

const gameHandler = (socket) => {
  // console.log("User Connected!");
  if (lobby.length == 0) {
    // Create new lobby and assign player 1 data
    createNewLobby(socket);
  } else {
    let lobbyCount = lobby.length - 1;
    if (lobby[lobbyCount].isFull) {
      console.log("All rooms full, creating new lobby...");
      createNewLobby(socket);
    } else {
      console.log("Found empty lobby, adding player 2..");
      lobby[lobbyCount].count = 2;
      lobby[lobbyCount].players.push({ player2: socket.id, color: "Red" });
      lobby[lobbyCount].isFull = true;
      console.log("=================================================");
      console.log(lobby);
      console.log("=================================================");
      socket.emit("room", { ...lobby[lobbyCount] });
      socket.broadcast.emit("updateState", { ...lobby[lobbyCount] });
    }
  }

  socket.on("move", (data) => {
    console.log(data);
  });

  socket.on("disconnect", (data) => {
    // console.log("User Disconnected!");
    lobby = [];

    console.clear();
  });
};

module.exports = gameHandler;
