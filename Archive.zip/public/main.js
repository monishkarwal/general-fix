let roomId = "";
let gameState = {};

const gameBoard = document.getElementById("game-board");
const columnButtons = document.getElementById("column-buttons");

for (let index = 1; index <= 7; index++) {
  let button = document.createElement("button");
  button.innerText = index;
  button.setAttribute("class", "btn");
  button.setAttribute("data-column", index);
  button.addEventListener("click", function () {
    console.log(this.dataset.column);
    socket.emit("move", { roomId, column: this.dataset.column });
  });
  columnButtons.appendChild(button);
}

for (let row = 0; row < 6; row++) {
  for (let col = 0; col < 7; col++) {
    let cell = document.createElement("div");
    cell.setAttribute("class", "cell");
    cell.setAttribute("data-row", row);
    cell.setAttribute("data-col", col);
    cell.addEventListener("click", function () {
      console.log(this.dataset.row, this.dataset.col);
    });
    gameBoard.appendChild(cell);
  }
  gameBoard.appendChild(document.createElement("br"));
}

function setupData(data) {
  // Check if room exist and discard unwanted data
  if (!roomId) {
    roomId = gameState.id;
    let lobbyId = document.getElementById("lobbyId");
    lobbyId.innerHTML = gameState.id;
    let player1Color = document.getElementById("player1-color");
    player1Color.innerHTML = gameState.players[0].color;
    let player2Color = document.getElementById("player2-color");
    player2Color.innerHTML = "Waiting...";
  }
  if (roomId && gameState.count == 2) {
    let player1Color = document.getElementById("player1-color");
    player1Color.innerHTML = gameState.players[0].color;
    let player2Color = document.getElementById("player2-color");
    player2Color.innerHTML = gameState.players[1].color;
  }
}

const socket = io();

socket.on("room", (data) => {
  gameState = data;
  setupData();
});

socket.on("updateState", (data) => {
  gameState = data;
  setupData();
});
